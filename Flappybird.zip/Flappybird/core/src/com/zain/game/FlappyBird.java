package com.zain.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;

import java.util.Random;

public class FlappyBird extends ApplicationAdapter
// ApplicationAdapter LibGdx Library File
{

	SpriteBatch batch;
	//Sprite is DataStructure defines how the Colour,structure,Texture,Position will set.
	// A Texture wraps a standard OpenGL ES texture.
	// You can draw Pixmaps to a texture at any time.
	// The changes will be automatically uploaded to texture memory.
	Texture background;
	// For background Image
	// ShapeRenderer shapeRenderer;
	Texture gameover;
	Texture restartButton;
	Texture highScoreButton;

	Texture[] birds;
	// Array Declared use for displaying Bird wing up and bird wing down and array size will be 2
	int flapState = 0;
	// Used for changing bird flap state (Wings Up and Down)
	float birdY = 0;
	//Float BirdY Responsible for continuously looping of images (bird wings up and wings down)
	float velocity = 0;
	// Velocity is Responsible for bird jump when touch operation is performed in render method.
	Circle birdCircle;
	// circle is a libgdx library
	int score = 0;
	int scoringTube = 0; //this variable will use for increasing score when bird will successfully passsed through the tube
	BitmapFont font;


	int gameState = 0;
	// The "game State" is used to control Bird from Falling before game starts, without this when game opens, the bird will fall and "Game Over" Message is displayed
	float gravity = 2;
	// I use "garvity variable" which will be used to Increase the bird falling speed, Without this Bird will fall slowly by default velocity value.
	// Increasing the value of gravity will increase the bird falling speed.
	Texture topTube;
	// Toptube variable will use to place Toptube.png image on screen.
	// Texture represents a single 2D texture in GPU memory, which can be used for rendering.
	Texture bottomTube;
	// bottom tube variable will use to place bottomtube.png image on screen.
	float gap = 400;
	//Gap will use for Gaping between Tubes
	float maxTubeOffset;
	//I declare maxtubeoffset that how maximum tubes distance will be.(on roof side (UP))
	Random randomGenerator;
	// It will use to generate random tubes height on every click on screen. (Using Random function)
	float tubeVelocity = 4;
	// This variable will be used to set the speed of moving tubes

	int numberOfTubes = 4;
	float[] tubeX = new float[numberOfTubes];
	float[] tubeOffset = new float[numberOfTubes];
	float distanceBetweenTheTube;
	// "distanceBetweenTheTube" variable will use to give dsitance between looping tubes.
	Rectangle[] topTubeRectangles;
	// "topTubeRectangles" variable will use for collision detection in toptube.png image
	Rectangle[] bottomTubeRectangles;
	// "bottomTubeRectangles" variable will use for collision detection in bottomtube.png image
	Rectangle restartButtonRectangle;
	Rectangle highScoreButtonRectangle;
	Preferences prefs;
	@Override
	public void create()
			// Render is a method for looping
	{

		restartButton=new Texture("res.png");
//		Preferences prefs = Gdx.app.getPreferences("FlappyBirdHighScore");
		highScoreButton=new Texture("high-score.png");
		restartButtonRectangle = new Rectangle(Gdx.graphics.getWidth() / 2 - restartButton.getWidth() / 2, Gdx.graphics.getHeight() / 2 - restartButton.getHeight() / 2+400, restartButton.getWidth(), restartButton.getHeight());
		highScoreButtonRectangle = new Rectangle(Gdx.graphics.getWidth() / 2 - highScoreButton.getWidth() / 2, Gdx.graphics.getHeight() / 2 - highScoreButton.getHeight() / 2, highScoreButton.getWidth(), highScoreButton.getHeight());
		batch = new SpriteBatch(); // Batch is used to Display any type of image (Format only PNG)
		background = new Texture("bg.png"); // Insertion of background Image
		gameover = new Texture("gameover.png");
		//shapeRenderer = new ShapeRenderer();
		birdCircle = new Circle();
		birds = new Texture[2];
		// Array size Declared (2) For bird wing up and down
		birds[0] = new Texture("bird.png");
		// For Bird wing up
		birds[1] = new Texture("bird2.png");
		// for bird wing down

		font = new BitmapFont();
		font.setColor(Color.WHITE);
		font.getData().setScale(10);

		topTube = new Texture("toptube.png");
		// insertion of toptube.png image
		bottomTube = new Texture("bottomtube.png");
		// insertion of bottomtube.png image
		maxTubeOffset = Gdx.graphics.getHeight() / 2 - gap / 2 - 100;
		randomGenerator = new Random();
		distanceBetweenTheTube = Gdx.graphics.getWidth() * 3 / 4;
		// "distanceBetweenTheTube" sets the logic, the distance between tubes
		topTubeRectangles = new Rectangle[numberOfTubes];
		//Insertion of image
		bottomTubeRectangles = new Rectangle[numberOfTubes];
		//Insertion of image

		startGame();


	}

	public void startGame()
	{
		birdY = Gdx.graphics.getHeight() / 2 - birds[flapState].getHeight() / 2;
		// it display the bird height to centre of screen
		for (int i = 0; i < numberOfTubes; i++)
		{
			tubeOffset[i] = (randomGenerator.nextFloat() - 0.5f) * (Gdx.graphics.getHeight() - gap - 200);
			//This will sets the logic for maximum height place for toptube on phone screen, Vertically X axis

			tubeX[i] = Gdx.graphics.getWidth() / 2 - topTube.getWidth() / 2 + Gdx.graphics.getWidth() + i * distanceBetweenTheTube;

			topTubeRectangles[i] = new Rectangle();
			bottomTubeRectangles[i] = new Rectangle();

		}
	}

	@Override
	public void render()
	// I created the Render method for looping structure only
	{
//		int highScore = prefs.getInteger("highScore", 0);
//		if (score > highScore) {
//			prefs.putInteger("highScore", score);
//			prefs.flush();
//		}
		batch.begin();  // Used to Start sprite method
		batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        // Gdx.graphic is library of gdx. get width method is used for width & get height is used for height of background image
		if (gameState == 1)
		{
			if (tubeX[scoringTube] < Gdx.graphics.getWidth() / 2) //
			{
				Gdx.app.log("Score", String.valueOf(score));
				score++;
				if (scoringTube < numberOfTubes - 1)
				{
					scoringTube++;
				}
				else
				{
					scoringTube = 0;
				}
			}

			if (Gdx.input.justTouched())
			// just.touched is a Gdx Library file, it works when touch is recognized.
			{

				velocity = -25;
				//velocity pushes the bird to jump upward, this define the length of jump of bird

			}
			for (int i = 0; i < numberOfTubes; i++)
			{

				if (tubeX[i] < -topTube.getWidth())
				{

					tubeX[i] += numberOfTubes * distanceBetweenTheTube;
					tubeOffset[i] = (randomGenerator.nextFloat() - 0.5f) * (Gdx.graphics.getHeight() - gap - 200);
				}
				else
				{

					tubeX[i] = tubeX[i] - tubeVelocity;

				}
				batch.draw(topTube, tubeX[i], Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffset[i]);
				batch.draw(bottomTube, tubeX[i], Gdx.graphics.getHeight() / 2 - gap / 2 - bottomTube.getHeight() + tubeOffset[i]);

				topTubeRectangles[i] = new Rectangle(tubeX[i], Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffset[i], topTube.getWidth(), topTube.getHeight());
				// this logic will detect the collision when bird hits the top tube
				bottomTubeRectangles[i] = new Rectangle(tubeX[i], Gdx.graphics.getHeight() / 2 - gap / 2 - bottomTube.getHeight() + tubeOffset[i], bottomTube.getWidth(), bottomTube.getHeight());// this logic will detect the collision when bird hits bottom tube
			}


			if (birdY > 0)
			{
				velocity = velocity + gravity;
				birdY -= velocity;
			}
			else
			{

				gameState = 2; //2 is the game over state
			}
		} else if(gameState==0)
		{

			if (Gdx.input.justTouched())
			{
				gameState = 1;
			}

		}
		else if(gameState==2)
		{
			batch.draw(gameover ,Gdx.graphics.getWidth()/2 - gameover.getWidth()/2,Gdx.graphics.getHeight()/2+700 -gameover.getHeight());
			batch.draw(restartButton, restartButtonRectangle.x, restartButtonRectangle.y);
			batch.draw(highScoreButton, highScoreButtonRectangle.x, highScoreButtonRectangle.y);
		//	batch.draw(highScoreButton, highScoreButtonRectangle.x, highScoreButtonRectangle.y);
			if (Gdx.input.justTouched())
			{
				gameState = 1;
				startGame();
				score =0;
				scoringTube=0;
				velocity = 0;
				if (gameState == 2) {
					if (Intersector.overlaps(restartButtonRectangle,highScoreButtonRectangle)) {
						// Restart game code goes here
						dispose();
						create();
					}
				}


			}

		}

		if (flapState == 0)
		{
			flapState = 1;
		}
		else
		{
			flapState = 0;
		}


		batch.draw(birds[flapState], Gdx.graphics.getWidth() / 2 - birds[flapState].getWidth() / 2, birdY);
		font.draw(batch , String.valueOf(score) , 100 , 200);


		batch.end();

		birdCircle.set(Gdx.graphics.getWidth() / 2, birdY + birds[flapState].getHeight() / 2, birds[flapState].getWidth() / 2);

  //     shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
    //   shapeRenderer.setColor(Color.RED);
      // shapeRenderer.circle(birdCircle.x ,birdCircle.y , birdCircle.radius);
//        These Shape renders are used during testing of collision
		for (int i = 0; i < numberOfTubes; i++)
		{

			//shapeRenderer.rect(tubeX[i],Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffset[i],topTube.getWidth(),topTube.getHeight());
			//shapeRenderer.rect(tubeX[i],Gdx.graphics.getHeight() / 2 - gap / 2 - bottomTube.getHeight() + tubeOffset[i], bottomTube.getWidth(),bottomTube.getHeight());
            //these shapeRendering conditions was written in order to check Rendering
			if (Intersector.overlaps(birdCircle, topTubeRectangles[i]) || Intersector.overlaps(birdCircle, bottomTubeRectangles[i]))
			//In this logic i use Intersector class which will use to detect collison and over lap is gdx badlogic library
			// The first condition Intersector toptube rectangle will represent uper tube collision only
			// The 2nd condition intersector bottomtube will detect bottomtube collision only
			// the birdcircle is actuall bird when collied with tube the gameover condtion will be printed
			{
             //Gdx.app.log("Collision","Yes");
			//This is created for testing only that collision will work or not, For Debugging pupose only
				gameState = 2;
			}
		}


		//shapeRenderer.end();


	}

}
